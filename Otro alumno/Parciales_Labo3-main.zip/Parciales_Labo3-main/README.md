# Parciales_Labo3
Parciales de Laboratorio 3 

# Primer Parcial
Parte BackEnd del primer parcial de programacion 3 (se utilizo AJAX para concectar FrontEND con BackEnd) (Desaprobado)

Errores
mostrarJSON -> NO muestra columna con input [type=color]
Luego del auto agregado, se muestra [object Object] (??)
verificarJSON -> si la patente no coincide con alguna dentro del listado, genera errores:
Uncaught SyntaxError: Unexpected token '<', "<br /> <fo"... is not valid JSON at JSON.parse (<anonymous>) at VerificarAutoJSON.xhttp.onreadystatechange (manejadora.ts:129:38)
mostrarSinFoto -> NO muestra columna con input [type=color]
Al seleccionar elemento agregado, genera errores:
auto.html:1 Uncaught SyntaxError: Invalid or unexpected token (at auto.html:1:52)
La columna ID (??) siempre muestra ‘undefined’
modificarSinFoto -> genera errores: VM233:2 Uncaught SyntaxError: Unexpected token '<', "
<br /> <fo"... is not valid JSON at JSON.parse (<anonymous>)
    at ModificarAutoBDSinFoto.xhttp.onreadystatechange (manejadora.ts:328:34)
NO MODIFICA.

en un futuro lo arreglo :s

# Primer Parcial Recuperatorio
Parte BackEnd Node.js dada por el profesor , conectado x ajax parte front con back
