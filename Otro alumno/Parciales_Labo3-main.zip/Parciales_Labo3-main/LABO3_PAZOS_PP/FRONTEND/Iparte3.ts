namespace PrimerParcial 
{ 
    export interface Iparte3 
    {

        VerificarAutoBD():void;
        AgregarAutoBDFoto():void;
        BorrarAutoBDFoto(obj: any):void;
        ModificarAutoBDFoto():void;
    }

}