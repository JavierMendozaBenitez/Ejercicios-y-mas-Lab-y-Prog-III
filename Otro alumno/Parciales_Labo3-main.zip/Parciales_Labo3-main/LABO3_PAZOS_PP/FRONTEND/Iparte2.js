"use strict";
//# sourceMappingURL=Iparte2.js.map