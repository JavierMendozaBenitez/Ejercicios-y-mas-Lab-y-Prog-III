namespace PrimerParcial 
{

    export interface Iparte2 
    {
      
      EliminarAuto(obj: any): void;
      ModificarAuto(): void;
    }

}