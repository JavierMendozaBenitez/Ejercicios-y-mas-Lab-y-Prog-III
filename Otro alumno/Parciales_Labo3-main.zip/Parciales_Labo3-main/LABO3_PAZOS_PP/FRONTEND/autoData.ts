interface AutoData 
{
    id: number;
    marca: string;
    patente: string;
    color: string;
    precio: number;
    pathFoto: string;
}