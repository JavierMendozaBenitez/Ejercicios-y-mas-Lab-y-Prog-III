<?php

interface IParte2
{
    static function eliminar(int $patente) : bool;
    function modificar() : bool;
}

?>