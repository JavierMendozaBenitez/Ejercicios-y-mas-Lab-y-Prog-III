<?php

 interface IParte1
{
    function agregar() : bool; // Puede cambiar
    static function traer() : array;
}

?>