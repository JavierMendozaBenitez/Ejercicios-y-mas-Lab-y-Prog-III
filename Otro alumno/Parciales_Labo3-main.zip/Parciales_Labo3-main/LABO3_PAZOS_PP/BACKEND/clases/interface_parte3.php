<?php

interface IParte3
{

    static function existe($patente) : bool;
    public function guardarEnArchivo(): string;

}


?>

