<?php
require __DIR__ . '/../src/app/app.php';
