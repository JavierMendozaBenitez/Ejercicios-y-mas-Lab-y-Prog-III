<?php

interface IParte2
{
    static function eliminar($patente) : bool;

    function modificar() : bool;
}

?>