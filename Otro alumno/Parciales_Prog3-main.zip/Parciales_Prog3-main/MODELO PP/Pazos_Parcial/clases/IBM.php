<?php

interface IBM
{
    public function ModificarBD();
    public static function EliminarBD(int $id);
}