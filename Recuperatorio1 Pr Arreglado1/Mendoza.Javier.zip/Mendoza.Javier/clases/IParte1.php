<?php

namespace Mendoza\Javier;

interface IParte1 {
    public function agregar();
    public static function traer();
    public function existe($ciudades);
}
