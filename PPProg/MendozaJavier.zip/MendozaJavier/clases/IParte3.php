<?php

namespace MendozaJavier;

interface IParte3
{
    public function existe(array $autos);
    public function guardarEnArchivo();
}
